# Price sensitivity

20 complete answers. Simulated buyers: use this to pick what to test, not as the final word.

| point | price | what it means |
| --- | ---: | --- |
| PMC | $9.32 | below this, too many think it is too cheap to be good |
| OPP | $9.32 | as many say too cheap as too expensive: the least resistance |
| IPP | $25.16 | as many call it a bargain as call it expensive |
| PME | $58.93 | above this, too many say it is too expensive to buy |

**Acceptable range: $9.32 to $58.93.**

Median answers: too cheap $9.00, a bargain $19.00, getting expensive $49.00, too expensive $99.00.
