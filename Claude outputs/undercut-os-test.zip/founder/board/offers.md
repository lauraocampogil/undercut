# Offers lens
Score: 4/10 | Vote: FUND IF

## What is strong
- **The dream outcome is the right one.** Small agencies want new clients. "Prospects plus an audit plus a message, every day" is much closer to that than "a dashboard". The previous idea (reporting) sold a nice-to-have, and this one sells revenue.
- **Effort and time look low.** You paste a URL and get a personal dashboard. If the first prospects appear within minutes, that part of the value equation is very good.
- **The stack is cheap to deliver.** The audits already exist in the live Undercut product. Turning a weak site into an audit, then a ready outreach message, is a real bundle that a scraper or a CRM does not give you on its own.

## What would kill it (the top 3, most dangerous first)
1. **No proof, so buyers will doubt it works.** The core promise depends on prospect discovery, and that is not built. Nobody has yet shown that these prospects reply, book calls or sign. Without one result like "X agency signed a client from this", the offer is just a claim.
2. **A weak market for paying.** Owners of 1–15 person agencies and freelancers in BE/FR/NL are price-sensitive and often swamped with work. Many already pay for something on the alternatives list or build it themselves for free with Claude, and the TikTok trend this rides on is DIY. A pain buyers will solve for free is not massive pain.
3. **The pitch is a pile of features, and the price looks like a commodity.** CRM, calendar, site problems and content ideas blur the one thing that matters. At €29–119 per month next to Apollo, scrapers and Notion templates, the buyer compares on price, and that is a fight this business loses. On top of that, GDPR exposure in B2B prospecting cuts against the outreach part.

## The questions I would ask the founder
- Of the prospects the tool would generate, how many convert into a paid project for a real agency? Can you show one?
- Why would an owner believe this beats a Maps scraper plus ChatGPT, which costs almost nothing?
- How long from signup until the first reply from a prospect?
- What do you guarantee?
- Could you charge €300 per month for "2 qualified client meetings a month" and still be the obvious choice?
- Which data source do you use, what does it cost per prospect, and is it GDPR-compliant?

## If FUND IF: the conditions
1. Build the smallest version of prospect discovery, even by hand. Run it for 3–5 real agencies and record the replies and meetings.
2. Rebuild the offer around one outcome, like client meetings or signed projects, not a list of dashboard blocks. Cut or bundle in everything that does not lead to that outcome.
3. Add a guarantee tied to that outcome, for example a refund if no qualified replies come within 30 days.
4. Get written confirmation that the data source is legal for B2B prospecting in BE/FR/NL before charging anyone.
