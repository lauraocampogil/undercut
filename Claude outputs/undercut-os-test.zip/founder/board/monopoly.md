# Monopoly lens
Score: 3/10 | Vote: PASS

## What is strong
- A real asset already exists. Undercut's audit engine (Lighthouse audits in a real Chrome, Search Console, error tracking, app store tracking) is built and live. Most rivals in the prospecting space don't run audits that deep, so it is the only thing here that could become proprietary know-how.
- The founder runs a small freelance studio herself, so she is part of the buyer group and can test it on her own work first.
- The geography is narrow: small agencies in BE/FR/NL. A narrow market is the right kind of market to start in, as long as there is a reason to win it.

## What would kill it (the top 3, most dangerous first)
1. **The trend is the competitor.** The pitch rests on a TikTok trend of people building their own agency dashboards with Claude. That trend shows the barrier is falling fast. Whatever a buyer can build in a weekend, a copycat can build too. There is no 10x gap here. It is a bundle of things that Apollo, Lemlist, Google Maps scrapers, HubSpot/Pipedrive and Notion templates already do on their own.
2. **The core feature isn't built and isn't owned.** The daily prospect list, which is the main reason to pay, depends on a business-data source that doesn't exist yet. Whoever owns that data controls its cost and access. GDPR rules on B2B prospecting add legal risk, and that risk is heaviest in exactly the EU market being targeted.
3. **Nothing gets stronger over time.** There are no network effects, no economies of scale and no brand. Each agency's dashboard is separate, so customer 100 makes the product no better for customer 101. White-label cuts the brand even further. In ten years, nothing here holds its position.

## The questions I would ask the founder
- What do you know about prospecting for small Benelux agencies that Apollo and the Maps scrapers don't?
- Which single block would an agency still pay for if you removed all the others?
- Why buy this rather than copy the TikTok tutorial? What stops a copycat in month six?
- Where does the prospect data come from, what does each prospect cost you, and is the outreach legal under GDPR as built?
- How do the first 100 paying customers arrive, and what does each one cost? Content reach is not a channel until it converts.
- The last agency tool lost to existing habits. What is different this time?
- Could the audit engine alone be the wedge, sold to a tighter niche where it is clearly the best option?

## If FUND IF: the conditions
Not applicable: the vote is PASS. It could be reopened if the founder shows a clearly superior proprietary asset (most likely the audit engine, aimed at one narrow niche), a legal and affordable source for prospect data, and at least a small group of paying customers who came through one repeatable channel.
