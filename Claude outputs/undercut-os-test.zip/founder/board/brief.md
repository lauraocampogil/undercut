# Undercut OS (pivot of Undercut)

- What it is: an auto-generated agency dashboard. The agency pastes its own website/app/social URL; the tool understands its services, niche and city and builds a personal dashboard: daily prospects (local businesses with weak websites/apps/socials, each with an audit + outreach message), pipeline/CRM, calendar (Google Calendar), problems on the agency's own site/app/socials (SEO, speed, errors), weekly content ideas. Blocks can be toggled; white-label.
- Who it is for: owners of small web, app, communication and social-media agencies and freelancers (1–15 people) in BE/FR/NL who want "their own dashboard" (a trend on TikTok: people building agency dashboards/prospecting tools with Claude) but can't build it themselves.
- What it sells, at what price: subscription — Solo €29/month (50 prospects), Studio €59 (300 prospects, 3 users), Agency €119 (1,000 prospects, 10 users); 14-day trial.
- Where and how: online SaaS; reuses the existing Undercut product (SEO/Lighthouse audits in a real Chrome, Search Console, heatmaps, error tracking, app store tracking, goals). Distribution via TikTok/Instagram content and outreach.
- Budget and constraints: solo founder (Laura, Brussels, web/mobile developer with a small freelance studio), near-zero budget; Undercut analytics is built and live; prospect discovery (business data source, e.g. Google Places/Maps data) is not built; GDPR rules on B2B prospecting apply.

## Extra context
- Previous idea tested (client-reporting tool for agencies): simulated panel 1/20 → 5/20 after offer changes; board 3.7/10; main blocker was habit vs GA4/Looker and existing reporting tools.
- Alternatives for this new idea include: Notion/ClickUp agency templates, CRMs (HubSpot, Pipedrive), lead-gen tools (Apollo, Lemlist, Phantombuster, Google Maps scrapers), agency OS tools, and DIY builds with Claude/ChatGPT seen on TikTok.
