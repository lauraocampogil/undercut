# Product lens
Score: 4/10 | Vote: FUND IF

## What is strong
- The first five minutes are a strong idea. You paste one URL and get a dashboard built for your agency. That is simpler than any Notion template or CRM setup.
- One block has a clear, concrete payoff: "today's local prospects with weak sites, each with an audit and a message ready to send." That pitch fits in one sentence.
- The audit engine (Lighthouse in real Chrome, SEO, errors) is already built and live. That is real craft the prospect audits can reuse.

## What would kill it (the top 3, most dangerous first)
1. **The one thing is the part that is not built.** Prospect discovery is the reason to buy, and it has no data source yet. Everything that is built (analytics, heatmaps, app store tracking, goals) is left over from a pivot the buyer did not want. The product is built backwards: it starts from existing code, not from the customer's moment.
2. **No focus.** Prospects, CRM, calendar, own-site health, content ideas, white-label and toggleable blocks are six products in one. A solo founder cannot make all six good, and the buyer already has a tool for most of them (Google Calendar, HubSpot/Pipedrive, Notion). Every block that is average makes the whole product feel average.
3. **Seams at the moment that matters.** The value chain goes Places-type data, then an audit, then a message, then sending (Gmail or Lemlist?), then a reply, then the CRM. Each handoff is outside the product or untested: data coverage in BE/FR/NL, GDPR-safe contact details, deliverability, and how good the generated message is. If the niche/city guess or the first prospect list is wrong, trust is gone on day one.

## The questions I would ask the founder
- In one sentence, with no "and": what does it do?
- Walk me through the first five minutes. What exactly is on screen after the URL is pasted, and how often is it right?
- Which three blocks would you delete tomorrow?
- Where do the prospects come from, what does that cost per prospect, and is it GDPR-safe in Belgium and France?
- Who sends the message, and what happens after a reply?
- Why would an agency pay €29 instead of copying the TikTok DIY build in an afternoon?

## If FUND IF: the conditions
1. Cut the product to one block: daily local prospects with audit and message. Move CRM, calendar, content ideas and white-label off the roadmap.
2. Build prospect discovery first and show 10 real agencies a list for their own niche and city. At least 7 must say the prospects are relevant, without coaching.
3. Have a written GDPR position on the data source and outreach before any paid plan goes live.
4. Show the full path from paste to sent message to logged reply working without a manual fix.
