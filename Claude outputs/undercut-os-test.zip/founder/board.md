# Board — Undercut OS (agency dashboard from a URL)
Vote: 2 FUND IF · 1 PASS — average 3.7/10 (Offers 4 FUND IF · Monopoly 3 PASS · Product 4 FUND IF)
Shared risks: (1) the reason to buy — daily prospects — is not built and depends on a data source; (2) six products in one (prospects, CRM, calendar, site health, content, white-label) — buyers already have most of them; (3) no proof that prospects reply; GDPR exposure on prospecting data.
Conditions: one block first (daily local prospects + audit + message); 7 of 10 real agencies confirm their own prospect list is relevant; documented data source + GDPR basis; proof of replies/signed clients.
Strongest version: a prospect engine for agencies — paste your URL, get real local businesses that need what you sell, each with a real audit (Lighthouse/SEO run in Chrome) and a message you send yourself. The dashboard grows around it later.
