# Buyer panel: Undercut OS — an auto-generated dashboard for agencies (web, app, communication, social media)

**4 buy · 16 pass** (20% buy) out of 20 simulated buyers. Seed 737936, so the same cards can be dealt again.

These are simulated buyers, not customers. Use this to find objections and weak spots, then confirm the big ones with real people before you spend.

## By segment

| group | buyers | buy rate |
| --- | ---: | ---: |
| Communication / social-media agency (2-15 people) | 7 | 43%  (thin) |
| Freelancer / solo studio (1-2 people) | 7 | 14%  (thin) |
| Small web or app agency (3-8 people) | 6 | 0%  (thin) |

## By buying behaviour

| group | buyers | buy rate |
| --- | ---: | ---: |
| Hunting for clients | 5 | 60%  (thin) |
| Tried building it with Claude/ChatGPT | 3 | 33%  (thin) |
| Notion / spreadsheet organiser | 4 | 0%  (thin) |
| Uses a CRM/agency tool | 2 | 0%  (thin) |
| Tool collector | 3 | 0%  (thin) |
| Price-sensitive | 3 | 0%  (thin) |

## By income

| group | buyers | buy rate |
| --- | ---: | ---: |
| $80,000 and up | 7 | 43%  (thin) |
| under $51,000 | 6 | 17%  (thin) |
| $51,000 to $80,000 | 7 | 0%  (thin) |

## Why they pass

| reason | buyers | in their words |
| --- | ---: | --- |
| trust | 10 | "I'd maybe poke at the free trial, but I wouldn't pay. I don't know where the prospect data comes from, and I'm not putting my agency's name on mass-sent messages built from scraped data without knowing it's GDPR-safe. I also have no proof these leads reply any better than my own cold DMs." (P003) · "I already run the agency from Notion and Google Calendar, and it works. I might poke at a free trial, but I wouldn't pay until I'd seen that the leads are real businesses I'd actually pitch, not a scraped list." (P004) |
| habit | 5 | "I already run my studio from Notion and Google Calendar, and it works well enough. I'd maybe poke at the free trial, but I wouldn't pay to replace a setup I already built and know." (P002) · "I already run the agency from Notion and Sheets, and this sounds like one more dashboard I'd have to check every day. The daily prospects are the only part that interests me, and I'm not paying a monthly fee to find out if they're any good." (P007) |
| need | 1 | "My calendar, clients and Instagram already live in Google and the tools I use, so another dashboard is one more tab I would not open weekly. I count every subscription and cancel what I do not use every week, and I do not see this surviving that test." (P019) |

## Why they buy

| reason | buyers | in their words |
| --- | ---: | --- |
| need | 4 | "I never have enough leads and I'm doing cold DMs by hand every week, so a daily list of local businesses with a slow or missing site plus a ready audit is exactly my bottleneck. 29 a month is less than one hour of my billable time, and the trial needs no card, so I'd try it and keep Solo if the leads are real." (P001) · "Finding leads eats hours of my week and I never have enough, so a daily list of local businesses with a ready audit and message is the one part I'd actually use. At 29 a month with a free trial and no card, I'd test it, and I'd keep paying only if the first prospects are real." (P008) |

## What would flip a no

- Seeing it run on my own URL in the trial and producing 5 or more genuinely relevant local prospects with audits I'd actually send, plus a Notion sync so I don't have to move my pipeline.
- A clear, written explanation of where the contact data comes from and why B2B outreach with it is GDPR-compliant, plus a real example of one prospect with an audit and message so I can judge the quality, or a case from another agency that got actual replies.
- Seeing a real sample of 10 prospects in my own area (Brussels) before signing up, then having 2 or 3 of them reply to me during the trial.
- Seeing real leads and audits generated for my own agency's URL during the free trial, with good quality for Brussels-area businesses. Also a named founder, a track record or references from other agencies, and an easy way to export my data if it shuts down.
- Seeing 10 real prospects it found for an agency like mine, in my area, where I can tell they are real, reachable businesses I would actually contact. After the trial, at least one of them would need to answer me.
- Seeing real prospects in my own area, with audits I could send as is, during the free trial and getting at least one reply from them, with an export to my current Notion or Sheets so I don't have to switch tools.
- Seeing it run on my own URL during the trial and getting 10 real local prospects I'd actually contact, with accurate audits, on day one. Or a client-facing example showing a reply or a signed deal from it.
- Seeing, during the trial, 10 real local prospects in my area that I'd honestly want to contact, with audits that are specific and accurate, and ideally proof that someone like me closed a client from it.
- A clear, specific explanation of how the prospect data is sourced and why outreach is compliant in BE/FR/NL, plus a trial where I see real prospects in my own area that are actually relevant, and the dashboard and calendar parts work without the prospecting.
- Seeing real agencies like mine using it and landing actual clients from the prospects, plus a way to export my data, so I'm not stuck if it shuts down.
- Seeing a real example for a business like mine, with 5 or 10 prospects that are actually relevant and already contacted by someone, or a first client won from the trial that pays for the subscription.
- A free trial where I see 10 real local prospects who match what I sell, with audits good enough to send as they are, and a price under 15 euros a month.

Buyers say they would buy **1.0 times** in the first month on average.

20 buyers gave all four price answers. Run founder-pricing's van_westendorp.py on the answers folder.
