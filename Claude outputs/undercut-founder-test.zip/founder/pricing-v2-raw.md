# Price sensitivity

20 complete answers. Simulated buyers: use this to pick what to test, not as the final word.

| point | price | what it means |
| --- | ---: | --- |
| PMC | $11.92 | below this, too many think it is too cheap to be good |
| OPP | $15.44 | as many say too cheap as too expensive: the least resistance |
| IPP | $30.11 | as many call it a bargain as call it expensive |
| PME | $78.80 | above this, too many say it is too expensive to buy |

**Acceptable range: $11.92 to $78.80.**

Median answers: too cheap $8.00, a bargain $20.00, getting expensive $60.00, too expensive $120.00.
