# Operations — Undercut (solo, SaaS)

## Stack & costs (feed cfo)
Hetzner VPS + Coolify (Germany) · Supabase (Frankfurt) · Resend (email) · Anthropic API (summaries, alt texts) · Google APIs (OAuth, GA4, GSC, PageSpeed) · Stripe (billing, to add) · GitHub. ~€70/month infra + ~€100 accounting/self-employed costs (estimates).

## Day-one routines
- Daily (10 min): Undercut on itself — Errors page, alerts, failed deployments in Coolify, waitlist/new signups.
- Weekly: backups restore test (monthly), reply to every beta agency, ship one improvement from their feedback, review the 3 marketing numbers.
- Per new agency: 20-min setup call within 48 h (bonus 4), check first report sent.

## Permits / legal to check (not legal advice)
- Belgian self-employed status + VAT number (EU B2B reverse charge), invoices via Stripe Tax/Invoicing.
- GDPR: privacy policy, DPA (Undercut = processor for agencies), sub-processor list (Hetzner, Supabase, Resend, Anthropic, Google), records of processing.
- Terms of service with liability cap (fixes on client sites!) and acceptable use.
- Google API: OAuth verification + Limited Use policy compliance for Google user data.

## Risk register
| risk | likelihood | impact | mitigation |
| --- | --- | --- | --- |
| VPS down / data loss | medium | high | daily off-site backups of /app/.data + Supabase PITR; uptime alert |
| A fix breaks a client site | low | high | suggestions only, preview/approve/undo, live check, liability cap in Terms |
| Google OAuth not verified / revoked | medium | high | start verification now; read-only scopes by default, manage scopes optional |
| Leaked keys | happened | high | rotate Supabase/Resend/SerpApi/cron keys; secrets only in Coolify |
| Founder burnout / time (solo + job search) | high | high | narrow scope to the core loop; 2 fixed weekly slots for customers |
| Competitor copies "to-do" view | medium | medium | speed + EU niche + done-with-you service |
