# Board — summary

**Vote: 2 FUND IF · 1 PASS — average 3.7/10** (Offers 4 FUND IF · Monopoly 3 PASS · Product 4 FUND IF)

## Risks raised by more than one member
1. Trust is missing (no proof, no DPA/EU-hosting page, unverified Google OAuth, script editing client sites) — all three.
2. Too many features, no single "one thing" — Offers + Product + Monopoly.
3. Switching cost/habit vs GA4, Looker Studio and existing tools — Offers + Monopoly.

## Conditions (checklist)
- [ ] One core loop: leads by source + "fix this week" → white-label report; hide the rest until asked
- [ ] Review/approve/undo + change log on every fix
- [ ] EU hosting statement, DPA, Privacy/Terms, verified Google OAuth, billing
- [ ] Time to first insight < 10 minutes, sample report public
- [ ] 3 named agencies with real before/after numbers
- [ ] Risk-reversal guarantee + free migration/setup
- [ ] 5–10 paying agencies within 60 days, one repeatable channel, known cost

## Strongest version the board can see
Not "all-in-one analytics", but **the retainer-proof report for small EU agencies**: every month, per client, where the leads came from and what was fixed — with your logo, ready in 10 minutes, hosted in the EU. The rest of Undercut (heatmaps, apps, goals) becomes the depth behind that one promise.

Disagreement kept: the Monopoly lens doubts any durable moat even then; Offers and Product think the narrowed offer can sell to a niche.
