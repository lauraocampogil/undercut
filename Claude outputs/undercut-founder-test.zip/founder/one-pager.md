# Undercut — one page

**Problem:** small agencies sell monthly retainers but can't show clients, in a way they understand, where leads come from and what was done; reporting eats half a day a month and tools are built for data analysts or priced per client (AgencyAnalytics ≈ $300+/month for 15 clients).

**Customer:** 1–15 person web/app/communication agencies in BE/FR/NL that sell maintenance or SEO retainers (beachhead: Belgium).

**Offer & price:** The Founding Agency Plan — the monthly client report your clients understand (leads by source, what changed, what to fix), white-label, ready in 10 minutes; read-only start, EU hosting + DPA, safe fixes with undo, done-with-you setup, 24 h guarantee. Solo €19 (5 clients) · Studio €39 (12) · Agency €79 (30); first 30 agencies −50% for life.

| number | value |
| --- | --- |
| Contribution per paying agency | €22/month (88%) |
| Break-even | 8 paying agencies |
| Year 1 (32 agencies by month 12) | ≈ €4.2k revenue, ≈ €1.7k operating profit (founder pay excluded) |
| Cash needed | ≈ €1.3k |

**Evidence:** simulated panel 1/20 → 5/20 after the narrowed offer (trust objections 7 → 0); competitors leave the "cheap + tells you what to do + EU" corner empty; product live on real client sites (Lighthouse, live fix verification, Search Console data).

**What the money/time is for:** trust pack + sample report (2.5 weeks), founding-agency outreach (8 Dec 2026).

**The ask:** 5 Belgian agencies to connect one real client in the next 2 weeks.
