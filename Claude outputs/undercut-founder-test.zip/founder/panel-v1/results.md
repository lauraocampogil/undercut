# Buyer panel: Undercut — analytics for agencies (web, app and communication agencies)

**1 buy · 19 pass** (5% buy) out of 20 simulated buyers. Seed 737936, so the same cards can be dealt again.

These are simulated buyers, not customers. Use this to find objections and weak spots, then confirm the big ones with real people before you spend.

## By segment

| group | buyers | buy rate |
| --- | ---: | ---: |
| Freelancer / solo studio (1-2 people, 3-10 clients) | 7 | 14%  (thin) |
| Small web or app agency (3-8 people, 10-25 clients) | 8 | 0% |
| Communication / marketing agency (5-15 people, campaigns + social) | 5 | 0%  (thin) |

## By buying behaviour

| group | buyers | buy rate |
| --- | ---: | ---: |
| No reporting at all | 4 | 25%  (thin) |
| Uses an agency reporting tool | 3 | 0%  (thin) |
| GA4 + Looker Studio loyal | 4 | 0%  (thin) |
| Sells retainers / maintenance | 3 | 0%  (thin) |
| Tool collector | 3 | 0%  (thin) |
| Price-sensitive | 3 | 0%  (thin) |

## By income

| group | buyers | buy rate |
| --- | ---: | ---: |
| under $56,000 | 6 | 17%  (thin) |
| $85,000 and up | 7 | 0%  (thin) |
| $56,000 to $85,000 | 7 | 0%  (thin) |

## Why they pass

| reason | buyers | in their words |
| --- | ---: | --- |
| habit | 11 | "I already have a reporting tool and my clients are used to the reports I send. GA and Search Console are free, and I'm not going to rebuild my monthly routine for a tool I've never heard of." (P001) · "I already have Looker Studio and GA4 templates for my clients and they work, so swapping them out means redoing the reports I've already built. Nothing in the offer says why this beats what I have enough to justify that work." (P003) |
| trust | 7 | "I already have my Looker Studio and GA4 templates built and my clients get their monthly report from them. A new tool from an unknown solo founder, and I have no idea if it will still exist next year." (P008) · "I don't report to my clients today and nobody has forced the issue, so I'm not going to pay to start. And a script on my clients' sites that edits titles and descriptions in one click is not something I'll risk on live sites. I might poke at it if it's free, but that's not buying." (P009) |
| need | 1 | "I'd probably sign up for the free beta because I sign up for everything, but I wouldn't pay. My clients don't read reports anyway, and I already have Google tools and a PDF I send monthly. With 3-10 clients I'd need the €59 plan, which is a lot for something I'd open twice and forget." (P013) |

## Why they buy

| reason | buyers | in their words |
| --- | ---: | --- |
| need | 1 | "A client just asked me why their leads dropped and I had nothing to show them. One screen per client with leads counted and a monthly report for 19 euros is cheap enough to try, especially free during the beta." (P002) |

## What would flip a no

- A free beta where I can import one real client in ten minutes, see a white-label report that looks better than what I send now, and see that the one-click SEO fixes work on my clients' CMS without breaking anything. Then I would pay only if it replaced my current tool, not on top of it.
- Clear proof it is GDPR-compliant (EU hosting, DPA I can sign), plus a white-label report that looks as good as my Looker Studio ones and a quick way to import or match my existing report. I'd test it on 2 clients for free first.
- A way to import my existing client reports and set-up, plus proof (a few agencies like mine using it) that the lead tracking really works. Then I would try it on 2 or 3 clients during the free beta, and pay if it replaced my current tool.
- If the one-click SEO fixes clearly saved me hours on my maintenance retainers, and it showed a number I could use to justify the retainer when a client asks 'is it working?'. Then I'd try the free beta at least.
- A real demo showing my monthly client report built automatically in under 10 minutes, with a one-click import of my existing setup, and a few agencies like mine vouching for it.
- A client who asks me for numbers and will pay for the reporting. Or a way to test it on one site with no snippet and no client sign-off, using only the Google connection.
- Seeing it import or match my existing GA4 and Looker Studio reports, a few named agencies already using it for months, and a promise that I can export my data and reports if it shuts down.
- Read-only mode with the fixes shown as suggestions I copy over myself, plus a sample monthly report I could send to a client as-is. Then the Freelance tier would be worth trying, though with 5-10 clients I'd need the middle tier.
- A way to import or mirror my existing Looker Studio/GA4 reports in a few minutes, plus proof the one-click SEO fixes work safely on WordPress and Webflow without breaking anything.
- Being able to import or mirror my existing Looker Studio report layouts, plus a review-and-approve step before any SEO fix goes live with an easy undo.
- A clear page saying EU hosting, a DPA I can sign, no consent banner needed, and a sample white-label report in my own branding that I can see before connecting any client. Then I'd test it on two clients.
- If it saved me real hours on the monthly report, with one click making the whole report and sending it, and a client told me they now read it. Or if a Freelance plan covered up to 10 clients for around €19-25.

Buyers say they would buy **1.0 times** in the first month on average.

20 buyers gave all four price answers. Run founder-pricing's van_westendorp.py on the answers folder.
