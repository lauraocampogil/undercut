# Pricing — Undercut

Simulated buyers (20, two rounds). Use to choose what to test, not as the final word.

| | v1 pitch (19/59/149) | v2 pitch (founding offer) |
| --- | ---: | ---: |
| Point of marginal cheapness | €14.9 | €11.9 |
| Optimal (least resistance) | €15.1 | €15.4 |
| Indifference (bargain = expensive) | €35.2 | €30.1 |
| Point of marginal expensiveness | €90.0 | €78.8 |
| **Acceptable range** | **€15–90** | **€12–79** |

Competitors for ~15 clients: Swydo $69 (≤10 sources), AgencyAnalytics ≈$300–375, Whatagraph $812+ (see competitors.md).

## Recommendation (to test)
- **Solo €19/month — 5 clients** (the panel's freelancers had 5–10 clients; 3 was too few)
- **Studio €39/month — 12 clients** (sits on the indifference point ~€30–35)
- **Agency €79/month — 30 clients** (just under the "too expensive" line, still 4× cheaper than AgencyAnalytics)
- **Founding agencies (first 30): −50% for life**, free until 31 Jan 2027. Write the real price next to it ("€39 → €19.50"), the v2 panel was confused by "50% off" on already-listed prices.
- Annual: 2 months free.

## The cheap test
Put these three prices on the landing + /beta form and ask "which plan would you pick after the beta?" — count real answers from real agencies before turning on Stripe.
