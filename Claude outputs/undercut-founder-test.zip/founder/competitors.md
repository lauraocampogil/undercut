# Competitors — Undercut

Sources read on 2026-11-19. Several price write-ups are published by competing tools (Coupler, Seline, Swydo): verify on each vendor's own price page before quoting them publicly.

## Who is there

| name | type | comparable price | notes |
| --- | --- | --- | --- |
| AgencyAnalytics | direct | $25/client/month (monthly) · $20 annual → **15 clients ≈ $300–375/month**, 50 clients ≈ $1,000–1,250 | the reference tool; add-ons extra (rank tracker $41.67/500 kw); 14-day trial, 30-day money-back. [coupler.io](https://blog.coupler.io/agencyanalytics-pricing/) |
| Whatagraph | direct | **from $812/month**, annual only | out of reach for 1–15 person agencies. [coupler.io](https://blog.coupler.io/?p=86143) |
| Swydo | direct | **$69/month** (10 sources, unlimited clients) + $2–4.50/extra source | closest on price; reporting + monitoring. [swydo.com](https://swydo.com/blog/swydo-vs-agencyanalytics/) |
| DashThis | direct | priced by dashboards/sources (price page not read) | each GA4 property = 1 source. [dashthis.com](https://dashthis.com/blog/new-pricing-2026/) |
| GA4 + Search Console + Looker Studio | substitute | free (but hours to build/maintain) | what 11/20 simulated buyers said they use out of habit |
| Plausible | indirect | ~$9–19/month for 1–10 sites | cookieless analytics, no agency reporting or leads. [seline.com](https://seline.com/blog/plausible-analytics-pricing) |
| Hotjar / Clarity | indirect | Clarity free | heatmaps only |

**Price range for "reporting for ~15 clients":** lowest ≈ $69 (Swydo, if ≤10 sources) · median ≈ $300 (AgencyAnalytics) · highest ≈ $812+ (Whatagraph). **Undercut Agency: €59 for 15 clients.**

## Positioning map (price × "tells you what to do")

- Expensive + data dashboards: Whatagraph, AgencyAnalytics
- Mid + data reports: Swydo, DashThis
- Free + DIY: Looker Studio/GA4
- Cheap + single job: Plausible (analytics), Clarity (heatmaps)
- **Empty corner: cheap + "what to fix this week" + leads + fixes it for you** → Undercut

## What their customers complain about (AgencyAnalytics, Capterra 4.8/117)

1. Rigid report customisation / white-label (≈7 of ~25 visible reviews) — e.g. "the inflexibility of the reporting". [capterra](https://www.capterra.com/p/158746/Agency-Analytics/reviews/)
2. Price per client too high (≈3) — "Pricing could be lower per client".
3. Missing features, e.g. Google Maps grid tracking (≈3, thin).
4. Bugs / support (≈2, thin). Learning curve (1, thin).

Whatagraph: entry price and annual-only billing (author's view, competitor source).

## The gap

- **Price for small agencies:** a 15-client agency pays ~$300+/month at AgencyAnalytics; Undercut is €59. That is a 5× difference — but the simulated panel said price was *not* the blocker; trust and habit were. So price is a door-opener in messaging ("the reporting tool built for 1–15 person agencies"), not the reason to switch.
- **Action, not dashboards:** every direct competitor sells reports/dashboards of data. None (in what was read) leads with "this week's to-do" + leads by source + fixes applied for you.
- **EU / GDPR-native + cookieless:** strong in BE/FR/NL, but only if proven (EU hosting, DPA) — today it is a claim.

## The threat

- AgencyAnalytics already ships "AgencyAI insights" and goals/alerts: it can add a "to-do" view fast.
- Swydo (NL, $69, unlimited clients) is the most direct price competitor for small EU agencies.
- Google can improve Looker Studio templates / GA4 insights for free.
