# Offers lens
Score: 4/10 | Vote: FUND IF

## What is strong
- The buyers are easy to find. Small BE/FR/NL agencies are listed, public and reachable by direct outreach at zero cost.
- "Leads, not pageviews" is a real dream outcome. Agency owners keep clients by proving the site makes money, and a count of forms, calls and WhatsApp clicks says that better than GA4 does.
- Delivery is cheap. It runs on one VPS, so a guarantee, white-label reports and done-for-you setup cost Laura time, not cash.
- The product already exists and runs on her own client sites, so she can start collecting proof today.

## What would kill it (the top 3, most dangerous first)
1. **Nobody believes it works yet.** There are no customers, no case studies, no DPA, no EU-hosting page, and the script edits client sites. In the simulated panel, 19 of 20 passed and trust was a top reason. When a buyer doubts the offer will deliver, they don't buy, however cheap it is.
2. **It asks too much effort and change.** The buyer has to install a snippet on every client site, leave GA4, Looker or a tool they already pay for, and trust automated fixes on sites they are paid to look after. Habit was the most common reason to pass (11 of 20). The price is not what stops them. The switching cost is.
3. **The pitch is a feature list leaning on a low price.** More than ten features, and the angle is "priced per agency". That makes it a cheaper AgencyAnalytics, which turns it into a commodity. The market's pain is moderate (monthly reporting is a chore, not an emergency), and the budgets of 1–15 person agencies are unproven.

## The questions I would ask the founder
- Which one outcome would an agency pay for even if every other feature disappeared?
- What hard numbers do your own client sites show, such as leads tracked or fixes that moved rankings?
- How many minutes does it take to go from signup to a first client report? (unknown)
- What do these agencies pay for reporting today, and how many hours a month does it cost them? (unknown)
- Would you guarantee it, for example "your first client report in 24 hours, or the month is free"?
- At €59, would anyone already pay? Could the price be €99 with setup done for them?

## If FUND IF: the conditions
1. Lead with one outcome: "a white-label leads report your client understands, ready in 10 minutes." Make the other features bonuses.
2. Before charging, publish EU hosting, a DPA, legal pages, and a review/undo step on every SEO fix.
3. Get 3 named agencies with real before/after numbers, and show a sample report on the landing page.
4. Add a risk-reversal guarantee and a free migration from an existing report. That removes most of the effort.
5. Turn on Stripe and get at least 5 paying agencies at list price within 60 days. Don't add a cheaper tier until then.
