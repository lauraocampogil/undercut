# Product lens
Score: 4/10 | Vote: FUND IF

## What is strong
- The angle is a real product idea, not a feature: "what to fix this week" in plain language, plus leads instead of pageviews. That moment of use (an agency owner opens one client screen and sees what changed and what to do) is the right place to start.
- It is built, live and used on the founder's own client sites. There is something real to cut down, so this is not a slide.
- Per-agency pricing is simple to understand, and it matches how an agency thinks about its client list.

## What would kill it (the top 3, most dangerous first)
1. **No one thing.** The brief lists more than twelve surfaces: leads, traffic, Search Console, SEO, Lighthouse, heatmaps, UTM, app store, paywall, errors, goals, one-click fixes and white-label reports. You cannot say it in one sentence, so the product is not clear yet. One solo developer cannot craft twelve surfaces well, and every half-finished one makes it look like a cheaper GA4 or AgencyAnalytics. 19 of 20 simulated buyers passing, mostly out of habit, is what happens when you don't say no.
2. **The scariest touchpoint ships without care.** The snippet changes live client sites. With no review step, no undo and no change log, one bad fix on a client's site ends the agency's trust and yours. Here the details nobody sees *are* the product.
3. **The first five minutes break at the seams.** Google OAuth is unverified, so the first connection shows a warning screen. There are no legal pages and no DPA page, so the GDPR question has no answer. There is no billing. Each of these is a handoff between systems, and each gives a buyer a reason to stop at the moment they decide whether to trust you.

## The questions I would ask the founder
- Say it in one sentence. Which feature would you keep if you had to delete all the others tomorrow?
- On your own client sites, which screen do you actually open each week, and which have you never opened?
- What does the first five minutes look like, from signup to the first useful insight? How long does it take, and where do people drop off? (No numbers given.)
- What happens if a one-click fix breaks a client's layout? Who sees it, and how is it undone?
- Does any client actually read the white-label report? What do they do after reading it?

## If FUND IF: the conditions
1. Cut to one core loop: leads by source plus "fix this week", with the report as its output. Hide everything else behind a flag until a paying agency asks for it.
2. One-click fixes need a preview, approval, undo and a visible change log before any agency outside the beta uses them.
3. Close the trust seams before charging: verified Google OAuth, an EU hosting statement, a DPA, legal pages and working billing.
4. Show one real sample white-label report and a time-to-first-insight under 10 minutes. Test this with 5 agencies that are not the founder's own.
