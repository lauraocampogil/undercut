# Undercut

- What it is: an analytics SaaS for agencies: one screen per client showing where leads come from (forms, calls, WhatsApp counted by a cookieless snippet), traffic, Google Search (Search Console), SEO + real Lighthouse checks, heatmaps, campaigns (UTM), app store tracking, paywall and error tracking for apps, client goals with next actions, one-click SEO fixes applied by the snippet, and a white-label monthly client report.
- Who it is for: owners / project leads of small web, app and communication agencies (1–15 people) in Belgium, France and the Netherlands who manage 5–40 client sites or apps and report to clients monthly.
- What it sells, at what price: monthly subscription per agency: Freelance €19 (3 clients), Agency €59 (15 clients), Studio €149 (50 clients). Free beta for the first 30 agencies.
- Where and how: online (getundercut.app), self-hosted on one VPS (Hetzner + Coolify), Supabase for multi-tenant data. Found through outreach to agencies, landing page, communities.
- Budget and constraints: solo founder (Laura, Brussels, web & mobile developer, runs a small freelance studio), near-zero budget, product already built and live in beta with her own client sites; no paying customers yet. Not yet: Stripe billing, Google OAuth verification, legal pages.

## Extra context
- Competitors in the space include agency reporting tools (AgencyAnalytics, DashThis, Whatagraph, Looker Studio templates, Semrush reports) and free Google tools (GA4, Search Console). Undercut's angle: plain-language "what to fix this week" + one-click fixes + leads instead of pageviews, priced per agency not per pageview.
- A first simulated buyer panel (20 AI buyers from this target) answered: 1 buy / 19 pass. Top reasons to pass: habit (already have GA4/Looker Studio or a reporting tool, 11), trust (unknown solo founder, GDPR/DPA unclear, script editing client sites feels risky, 7), need (clients don't read reports, 1). Most-asked flips: import/mirror existing reports, EU hosting + DPA page, review/undo before SEO fixes, sample white-label report, proof from similar agencies, a 5–10 client plan around €25–29.
