# Monopoly lens
Score: 3/10 | Vote: PASS

## What is strong
- The product exists and runs on real client sites. That is rare at this stage, and it costs almost nothing to run (one VPS).
- There is a small market it could plausibly own: 1–15 person agencies in Belgium, France and the Netherlands that report monthly and care about leads, not pageviews. It is multilingual and EU-sovereign, so US tools are likely to underserve it. That is the right shape for a first beachhead.
- The snippet that applies SEO fixes is the only part that acts, where rivals only report. If it works safely, it is the start of a real technical edge.

## What would kill it (the top 3, most dangerous first)
1. **A crowded market with no 10x edge.** AgencyAnalytics, DashThis, Whatagraph, Semrush and free GA4/Looker Studio already sit in front of this exact buyer. "Plain language plus cheaper" is an incremental gain, not a breakthrough. In the simulated panel, 11 of 20 passed out of habit, which is what a market looks like when it has no room for another tool.
2. **No distribution engine.** Outreach, a landing page and communities make a list of channels, not a system. With 1 buy out of 20 simulated buyers, no proof and no billing, there is no evidence that the first 100 agencies arrive at a cost a €19–149 plan can carry.
3. **Nothing durable.** It has no network effect, no economies of scale and no brand yet. The 13-module feature spread is easy to copy one piece at a time, and any incumbent can ship "what to fix this week" in month six. The one possible moat, one-click fixes, is also the biggest trust risk (7 of 20 named it).

## The questions I would ask the founder
- What do you know about these agencies that AgencyAnalytics does not? Name the secret in one sentence.
- Which single module is 10x better than the free option, and how have you measured it?
- How many BE/FR/NL agencies of 1–15 people exist? (Open: the market size is unknown.)
- What does it cost to acquire one paying agency, and what is churn? (Open: there is no data.)
- Could fix data gathered across many agency sites compound into something a copycat cannot get?
- Why now? What changed (cookie rules, GA4 pain, AI search) that opens this window today?

## If FUND IF: the conditions
Not applicable at PASS. What would move it to FUND IF:
- Cut to one wedge (for example leads attribution plus safe one-click fixes) and show it beats GA4/Looker Studio on that one job.
- 10 paying agencies in one country, each acquired through one repeatable channel at a known cost.
- An EU-hosting/DPA page plus review-and-undo on fixes, to remove the trust objection that blocks the only potential moat.
