# Brand — Undercut (name kept)

- Name: **Undercut** (already in use, domain getundercut.app owned). Checks to run yourself before spending on brand: EUIPO/BOIP trademark search for "Undercut" in class 42 (SaaS) and 35 (marketing services); LinkedIn/Instagram/X handle "getundercut".
- Promise: "Where the leads came from, what to fix this week — for every client, in plain words."
- Voice: direct, a bit rebellious against dashboard bloat, never jargon; numbers + one action. Do: short sentences, "your client", concrete examples. Don't: "insights", "synergy", hype, fake urgency.
- Look: dark + lime gradient landing (current), light dashboard; Instrument Serif headlines + Geist; the "cut" bar motif.
- Trust signals to add: founder face/name + Brussels address on landing, EU hosting badge, DPA link, changelog.
