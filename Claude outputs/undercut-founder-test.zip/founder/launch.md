# Launch — Founding agencies

## Cheap real-world test first (this week)
Landing + public sample report + "Reserve a founding seat" form with the 3 prices ("which plan after the beta?"). Send to 50 Belgian retainer agencies. **Pass bar: ≥ 5 real agencies connect a real client within 7 days, ≥ 2 say they'd pay.** If not, change the message before building more.

## Countdown (launch = 8 Dec 2026)
- T-14 (24 Nov): DPA + Privacy + Terms live; review/undo on fixes; read-only report flow; sample report page.
- T-10 (28 Nov): Stripe test mode with founding prices; Resend domain verified; Google OAuth verification submitted.
- T-7 (1 Dec): Loom demo; 150-agency list; messages ready; backups + uptime alert on.
- T-3 (5 Dec): full run-through as a new agency (signup → report in < 10 min) on a phone and a laptop.
- T-1 (7 Dec): warm DMs; seats counter set to the real number.

## Launch-day run sheet (8 Dec)
09:00 LinkedIn post · 09:30 first 30 DMs/emails · 12:00 community posts · 14:00 answer every reply within 1 h · 17:00 book setup calls · 20:00 note numbers (sent, replies, signups, connected clients).

## First 30 days
Week 1: 20-min setup calls, fix every onboarding bug same day. Week 2: first agencies send their first white-label report to a real client — ask what the client said. Week 3: case study #1 (real numbers, permission). Week 4: pricing question to every beta agency; decide Stripe go-live for 1 Feb 2027.
