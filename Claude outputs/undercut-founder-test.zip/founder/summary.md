# Summary

Undercut is an analytics and client-reporting SaaS for small web, app and communication agencies (1–15 people) in Belgium, France and the Netherlands: per client, where the leads came from, what changed and what to fix this week, sent as a white-label report.

**Verdict: Profitable — barely, and only on estimates.** Contribution 88% per paying agency (€22 of a €25 blended year-1 price), break-even at 8 paying agencies, year-1 operating profit ≈ €1.7k at 32 agencies by month 12 — founder pay not included. To earn a living (~€3k/month) Undercut needs roughly 100–150 paying agencies at list prices.

**Panel and board agree:** trust and switching effort block the sale, not price. Narrowing to one promise and adding a trust pack moved the simulated buy rate from 5% to 25% and removed every trust objection; habit (GA4/Looker/existing tools) remains. Retainer-selling agencies are the beachhead (3/3 bought). **They disagree** on the moat: the Monopoly lens passes (crowded market, no 10× edge), Offers and Product fund it if narrowed and proven.

**Biggest risk:** no real proof yet — zero paying agencies, no case study. Answer: the founding-agency test (50 Belgian retainer agencies, pass bar 5 connect a real client in 7 days, 2 say they'd pay).

**To start:** ~€1.3k of cash at most (legal review, small tests) and ~2.5 weeks of product fixes (DPA/Privacy/Terms, review/undo on fixes, read-only report flow, public sample report).

**This week:** publish a real sample report page and the DPA/privacy pages, then message the first 20 Belgian agencies that sell maintenance/SEO retainers.

_The panel is simulated buyers and the numbers are projections — real agencies and real invoices confirm them. Not financial, legal or tax advice._
