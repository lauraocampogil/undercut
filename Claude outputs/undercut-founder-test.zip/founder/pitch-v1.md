Undercut — analytics for web, app and communication agencies (getundercut.app).
One screen per client: where leads come from (forms, calls, WhatsApp — counted automatically), traffic, Google Search, SEO and Lighthouse checks, heatmaps, campaigns, app store and errors, in plain words with a "this week's to-do".
Connect Google once, paste one cookieless line on each client site. Many SEO issues (titles, descriptions, image texts) can be fixed in one click from Undercut without opening the CMS. White-label monthly report for clients.
Price per agency, not per pageview: Freelance €19/month (3 clients), Agency €59/month (15 clients), Studio €149/month (50 clients).
Free during the beta for the first 30 agencies.
