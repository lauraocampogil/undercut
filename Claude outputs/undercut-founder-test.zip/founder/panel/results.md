# Buyer panel: Undercut — analytics for agencies (web, app and communication agencies)

**5 buy · 15 pass** (25% buy) out of 20 simulated buyers. Seed 737936, so the same cards can be dealt again.

These are simulated buyers, not customers. Use this to find objections and weak spots, then confirm the big ones with real people before you spend.

## By segment

| group | buyers | buy rate |
| --- | ---: | ---: |
| Freelancer / solo studio (1-2 people, 3-10 clients) | 7 | 29%  (thin) |
| Small web or app agency (3-8 people, 10-25 clients) | 8 | 25% |
| Communication / marketing agency (5-15 people, campaigns + social) | 5 | 20%  (thin) |

## By buying behaviour

| group | buyers | buy rate |
| --- | ---: | ---: |
| Sells retainers / maintenance | 3 | 100%  (thin) |
| Tool collector | 3 | 33%  (thin) |
| No reporting at all | 4 | 25%  (thin) |
| Uses an agency reporting tool | 3 | 0%  (thin) |
| GA4 + Looker Studio loyal | 4 | 0%  (thin) |
| Price-sensitive | 3 | 0%  (thin) |

## By income

| group | buyers | buy rate |
| --- | ---: | ---: |
| under $56,000 | 6 | 33%  (thin) |
| $85,000 and up | 7 | 29%  (thin) |
| $56,000 to $85,000 | 7 | 14%  (thin) |

## Why they pass

| reason | buyers | in their words |
| --- | ---: | --- |
| habit | 14 | "I already pay for a reporting tool and my clients are used to those reports. Switching means rebuilding templates and re-connecting every client, and I have never heard of Undercut. The price is fine, it's the hassle and the risk of a tool that might not exist next year." (P001) · "I already have Looker Studio templates built on GA4 for my clients and they cost me nothing. Redoing that in a new tool for a 10-minute saving doesn't feel worth it, and I'd be wary of putting my clients' data in something from a one-founder startup I've never heard of." (P003) |
| need | 1 | "I'd probably sign up for the free trial because I do that with everything, but that's not buying. My clients don't read the reports I already send, so a nicer one doesn't fix anything for me. I'd only pay if it clearly saved me hours or got clients to react." (P013) |

## Why they buy

| reason | buyers | in their words |
| --- | ---: | --- |
| need | 4 | "A client just asked me why their leads dropped and I had nothing to show them, so a report I can send in ten minutes is a real gap. It's free until January and read-only, so trying it costs me an hour, not money." (P002) · "The monthly PDF is a time sink and my clients never read it, so a report they understand in 10 minutes is worth a try, especially free until January and read-only so I don't touch client sites. I'd connect one or two clients first, not all of them." (P012) |
| convenience | 1 | "It's free until end of January, EU-hosted with a DPA and read-only start, so the GDPR question I always ask is answered and I lose nothing by connecting Google for one client. I sign up for trials like this all the time, so I'd try it, but I wouldn't commit to paying yet." (P017) |

## What would flip a no

- A real sample report I could send to a client as-is, plus proof that other small agencies already use it and that it does the leads (forms, calls, WhatsApp) part better than my current tool.
- A way to import or mirror my existing Looker Studio layouts, or a case study from an agency like mine showing the monthly report really takes 10 minutes. I'd also want to see a real sample report with a client's data before connecting anything.
- A real sample report for a site like my clients' that answers 'why did leads go down' better than what I send now, plus proof that I can run it next to my current tool for a month without migrating anything.
- A client actually asking me for proof that the retainer works, or seeing a report in 10 minutes that I could use to justify raising a retainer price or stop a client from cancelling.
- Seeing a real report for a client like mine, plus proof it replaces my current tool for one client at no cost, with a founder I can reach.
- A client asking me for monthly numbers, or a case from another small agency like mine that lost a client for lack of a report. Better still, one client where I connect Google myself in 10 minutes and get a report I can send the same day without asking anyone.
- A Looker Studio template import or a clear migration path so I don't lose my existing reports, plus a few named agencies I recognise already using it for a year or more.
- A real sample report for a small client site that I can read in two minutes, plus proof that the read-only Google connection touches nothing on the client's site and nothing gets changed without me.
- Proof that it tracks calls and WhatsApp leads reliably, which GA4 can't do, plus a first client report that looks better than my Looker one with no template work on my side. I'd try the free period, but I'd only pay if it replaced Looker rather than sitting beside it.
- A real sample report for an agency like mine that looks better than my Looker Studio one, plus proof that I can import or match my existing templates so I don't redo the work. Seeing another agency in Belgium use it would help.
- Seeing a real report that one of my clients would actually reply to, or proof it cuts my monthly reporting from hours to minutes on my own 5-8 clients.
- A real sample report I could show a client that explains why their leads dropped, and that tracks calls and WhatsApp leads, which GA doesn't do well. If a client asked for it, or it saved me a few hours each month, I'd pay.

Buyers say they would buy **1.0 times** in the first month on average.

20 buyers gave all four price answers. Run founder-pricing's van_westendorp.py on the answers folder.
