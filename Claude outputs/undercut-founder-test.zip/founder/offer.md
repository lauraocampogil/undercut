# Offer — "The Founding Agency Plan"

## Problem list (buyer's words, from the panel)
Before buying: "GA4/Search Console are free" · "I already have Looker Studio / a reporting tool" · "rebuilding my reports is work" · "unknown solo founder, will it exist next year?" · "GDPR: where is the data, is there a DPA?" · "a script editing my clients' sites is risky" · "my clients don't read reports" · "3 clients is too small a plan" · "I need my clients' agreement to install a snippet".
During: "no time to learn another dashboard" · "is the WhatsApp / call tracking accurate?" · "I want to see my own client's data in 10 minutes".
After: "can I export if it shuts down?" · "what if a fix breaks a layout?" · "will clients actually react?"

## The stack (value high / cost low kept)
- **Core:** the monthly client report your clients understand — leads by source, what changed, what to fix this week — white-label, ready in 10 minutes.
- **Bonus 1 — Read-only start:** first report from the Google connection alone, no snippet, no client sign-off (kills "snippet on every site", "client must agree").
- **Bonus 2 — Trust pack:** EU hosting (Germany), signable DPA, export anytime, public status/changelog (kills GDPR + "will it exist").
- **Bonus 3 — Safe fixes:** fixes are suggestions; preview → approve → undo, change log, checked live in a real browser (kills "script is risky").
- **Bonus 4 — Done-with-you setup:** 20-minute call with the founder to set up the first client (kills "no time to learn"). Costs founder time only.
- **Guarantee:** first client report within 24 h of connecting Google, or the founder sets it up with you on a call. Cancel anytime, keep your export.
- **Urgency (true):** 30 founding seats; founding price for life.
- **Name:** "The Founding Agency Plan".

## Value equation (1–10, before → after)
- Dream outcome: 6 → 7 (leads report clients understand)
- Perceived likelihood: 3 → 6 (trust pack, read-only start, guarantee)
- Time to result: 5 → 8 (10 minutes, 24 h promise)
- Effort & sacrifice: 3 → 6 (no snippet needed, done-with-you)

## Re-test (same 20 buyers, same seed)
- **v1: 1 buy · 19 pass (5%) → v2: 5 buy · 15 pass (25%).**
- Trust objections: **7 → 0**. Habit: 11 → 14 (now the only big blocker).
- "Sells retainers / maintenance": **3/3 buy** → the beachhead segment.
- GA4/Looker-loyal and agencies on a reporting tool: still 0% → don't target them first.
- #1 thing that would flip the rest: **a real sample report** (asked by ~12/15), then "import/mirror my Looker template" and "proof call/WhatsApp tracking is accurate".

What must be true before promising it: the DPA page, review/undo on fixes, the read-only report flow and the sample report must exist in the product (see the fix list).
