# Unit economics: Undercut (estimates; year-1 blended price after founding discounts)

Every number below comes from the input file. Nothing is looked up or guessed.

## One paying agency per month

| line | per paying agency per month |
| --- | ---: |
| Price | $25.00 |
| Stripe fees (~1.5% + €0.25, EU cards) | -$0.93 |
| AI summaries + alt texts (Anthropic API, estimate) | -$1.50 |
| Emails (Resend) + storage per agency (estimate) | -$0.50 |
| **Contribution** (what each paying agency per month leaves to pay the fixed costs) | **$22.07** (88%) |

## The margin that matters

Fixed costs: $170 a month (VPS Hetzner (estimate) $20, Supabase Pro (when the free tier is outgrown) $25, Domain, Resend, backups, monitoring (estimate) $25, Accounting / social status as self-employed in Belgium (estimate, founder pay not included) $100).

- **Break-even: 8 paying agency per months a day.** Below that you lose money every month.
- **Profit margin at your plan** (32 a day): **67%** of every sale, after every cost.
- Capacity: 1000 a day.

## Year 1, month by month

| month | paying agency per months a day | revenue | profit | cumulative (after $800 startup) |
| ---: | ---: | ---: | ---: | ---: |
| 1 | 0 | $0 | -$170 | -$970 |
| 2 | 0 | $0 | -$170 | -$1,140 |
| 3 | 3 | $75 | -$104 | -$1,244 |
| 4 | 6 | $150 | -$38 | -$1,281 |
| 5 | 9 | $225 | $29 | -$1,253 |
| 6 | 12 | $300 | $95 | -$1,158 |
| 7 | 15 | $375 | $161 | -$997 |
| 8 | 18 | $450 | $227 | -$770 |
| 9 | 21 | $525 | $293 | -$476 |
| 10 | 25 | $625 | $382 | -$94 |
| 11 | 28 | $700 | $448 | $354 |
| 12 | 32 | $800 | $536 | $890 |

- **Year 1 operating profit: $1,690** on $4,225 of revenue.
- After the $800 startup spend: $890.
- Startup money earned back: month 11.
- Cash you need before it pays for itself: **$1,281**.

## What if

| scenario | margin at plan | break-even a day | year 1 profit |
| --- | ---: | ---: | ---: |
| Base plan | 67% | 8 | $1,690 |
| Price -10% | 63% | 9 | $1,267 |
| Volume -20% | 62% | 8 | $944 |
| Unit costs +15% | 65% | 8 | $1,616 |

No red flags in these numbers. They are only as good as the inputs: check every cost against a real quote.
