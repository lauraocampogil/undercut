# Marketing — first 30 founding agencies

## Positioning (recommended: A)
**A.** For small agencies that sell monthly retainers and need to prove they're worth it, Undercut is the client report that shows where the leads came from and what was fixed this month — in plain words, with your logo — unlike GA4/Looker dashboards clients never read.
B. For freelancers whose clients ask "is the website working?", Undercut gives a one-screen answer per client in 10 minutes.
C. The EU-hosted, cookieless reporting tool built for 1–15 person agencies, 4× cheaper than AgencyAnalytics.
Evidence: v2 panel — retainer sellers 3/3 buy; "a client asked why leads dropped" is the strongest buy trigger; price is a door-opener, not the reason (competitors.md).

## Channels (start with 2, plus your network)
1. **Direct outreach (LinkedIn + email) to BE agencies selling maintenance/SEO retainers** — free, measurable (reply rate, demo booked). Target list: Webflow/WordPress agencies on Clutch/Sortlist/Google Maps Brussels-Wallonia-Flanders, 1–15 people. 10 personal messages/day.
2. **Communities where these people are:** Belgian/French web & Webflow/WordPress groups, Indie Hackers, r/agency, Slack/Discord of Webflow & SvelteKit, BeCentral/Brussels startup events. Show, don't pitch: post one real anonymised report.
3. **Your own network:** EhB alumni, AKIS.studio contacts, freelancers you know, Unix Creative Studio clients' other agencies.
Not now: paid ads (no proof yet, max CAC too low), Product Hunt (wait for 3 case studies).

## The most you can pay for an agency
Contribution ≈ €22/agency/month (year-1 blended €25 − ~€3 costs, cfo.md). If an agency stays 12 months → ~€264. Keep acquisition under **€65 (3-month payback)** → founder time + free channels only for now.

## Ten hooks (each answers one panel objection)
1. "Your client asked why their leads dropped. Here's the answer in one screen." (need trigger)
2. "Prove your retainer is worth it — every month, in 10 minutes." (retainer sellers)
3. "No snippet needed. Connect Google, get your first client report today." (switching effort)
4. "Hosted in Germany. DPA ready to sign. Your clients' data never leaves the EU." (GDPR)
5. "Every SEO fix is a suggestion. You approve it, you can undo it." (script risk)
6. "Looker Studio shows data. Undercut shows what to do." (habit)
7. "AgencyAnalytics: ~$300/month for 15 clients. Undercut: €39." (price, door-opener)
8. "Calls, forms and WhatsApp counted per channel — no events to set up." (leads accuracy)
9. "Built in Brussels by an agency founder, for agencies like yours." (unknown founder)
10. "See a real report before you connect anything." (#1 flip: sample report)

## 30-day calendar (launch day = 8 Dec 2026, founding seats open)
- **24–30 Nov (T-14…T-8):** finish trust fixes (DPA page, Privacy/Terms, review/undo, sample report). Build target list of 150 BE agencies (retainer sellers first). Write 3 message variants (hooks 1, 2, 3).
- **1–7 Dec (T-7…T-1):** record a 90-second Loom on BSA's real report. Publish the public sample report page. Warm DMs to 20 people in your network. Post "building in public" on LinkedIn (behind the scenes: one real fix verified live).
- **8 Dec (launch):** LinkedIn post (hook 2 + sample report link), email/DM to the 150-agency list in batches of 30/day for 5 days, community posts.
- **9–14 Dec:** 30 DMs/day, book 20-min setup calls (bonus 4). Share one tip/day from real data (hooks 6, 8).
- **15–24 Dec:** follow-ups (2 max), case study #1 drafted with first agency's permission. Seats-left update only if true.
- **Holiday pause 25 Dec–1 Jan:** scheduled LinkedIn posts only.
- **2–9 Jan (T+25…T+32):** follow-up wave + first case study published; ask beta agencies which plan they'd pick (pricing test).

## Weekly numbers (and the "change something" line)
- Outreach → reply rate (< 8% → change the message/hook)
- Replies → setup calls booked (< 30% → change the offer/landing)
- Calls → agency connected a real client within 24 h (< 60% → fix onboarding)
